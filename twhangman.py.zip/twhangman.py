theword = input("Input Word:")
correct_word_list_unsorted = list(theword)
correct_word_list = sorted(correct_word_list_unsorted)
correcly_guessed_list = []
i = 0
b = len(correct_word_list)
a = b + 2
print("Length of word:",b)

for x in range(0, a):
    i +=1
    guess = input("Guess a letter:")
    if guess in correct_word_list:
        correcly_guessed_list.append(guess)
        print("Correct guess!", guess, "is a letter in the word" )
        print(correcly_guessed_list)
        sorted_corrrecly_guessed_list = sorted(correcly_guessed_list)
        if sorted_corrrecly_guessed_list == correct_word_list:
            print("Congratulations! You won! The word was:", theword)
            break
    else:
        print("Incorrect guess!")
    if i==a:
        print("You lost")
    print("remaining guess:", a-i)

    # Remaining: #1 Doesn't lose a guess, when guessing correctly
    #            #2 _ i _ _ _ r
    #            #3 Shows the answer, if loosing?    